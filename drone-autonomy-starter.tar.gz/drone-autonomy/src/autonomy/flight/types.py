"""Data types that flow through the flight controller interface.

These are pure data classes — no behavior. The point is to have a stable,
backend-agnostic vocabulary for talking about drone state. Whether the
underlying autopilot is ArduCopter, PX4, or INAV, the rest of the application
sees the same Telemetry and FlightMode types.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from time import time


class FlightMode(str, Enum):
    """Generic flight modes mapped onto autopilot-specific modes by each adapter.

    The string values match ArduCopter mode names for convenience, but the PX4
    and INAV adapters translate them to their respective equivalents.
    """

    STABILIZE = "STABILIZE"
    ALT_HOLD = "ALT_HOLD"
    LOITER = "LOITER"
    GUIDED = "GUIDED"       # the workhorse — companion-driven setpoints
    AUTO = "AUTO"           # waypoint missions
    RTL = "RTL"             # return to launch
    LAND = "LAND"
    UNKNOWN = "UNKNOWN"


class GPSFixType(int, Enum):
    """GPS fix quality. Values match MAVLink GPS_FIX_TYPE."""

    NO_GPS = 0
    NO_FIX = 1
    FIX_2D = 2
    FIX_3D = 3
    DGPS = 4
    RTK_FLOAT = 5
    RTK_FIXED = 6


@dataclass(frozen=True)
class Position:
    """Global position in WGS84.

    Altitude is meters above mean sea level (AMSL).
    `relative_alt_m` is meters above the takeoff/home position — usually what
    you actually care about for "how high am I flying."
    """

    lat: float            # degrees
    lon: float            # degrees
    alt_m: float          # meters AMSL
    relative_alt_m: float # meters above home


@dataclass(frozen=True)
class Attitude:
    """Drone orientation in radians."""

    roll: float
    pitch: float
    yaw: float


@dataclass(frozen=True)
class Velocity:
    """Velocity in the NED (North-East-Down) frame, m/s.

    NED is the standard aviation reference frame: +x is north, +y is east,
    +z is *down*. Yes, down is positive — get used to it. ArduPilot, PX4,
    and MAVLink all use NED for position/velocity setpoints.
    """

    vx_ned: float
    vy_ned: float
    vz_ned: float


@dataclass(frozen=True)
class Battery:
    voltage_v: float
    current_a: float
    remaining_pct: int  # -1 if unknown


@dataclass(frozen=True)
class Telemetry:
    """Snapshot of drone state at a moment in time.

    The FlightController.get_telemetry() method returns one of these. The
    state machine reads it every tick and decides what to do next.
    """

    timestamp: float            # unix time when this snapshot was assembled
    position: Position | None   # None until GPS lock
    attitude: Attitude
    velocity: Velocity
    mode: FlightMode
    armed: bool
    gps_fix: GPSFixType
    satellites_visible: int
    battery: Battery
    heading_deg: float          # compass heading 0-360

    # Health flags surfaced from the autopilot
    ekf_ok: bool = True
    prearm_ok: bool = True

    @classmethod
    def empty(cls) -> Telemetry:
        """A safe 'we have no data yet' telemetry object.

        Used at startup before the first heartbeat arrives. Anything reading
        this should treat it as 'do not act.'
        """
        return cls(
            timestamp=time(),
            position=None,
            attitude=Attitude(0.0, 0.0, 0.0),
            velocity=Velocity(0.0, 0.0, 0.0),
            mode=FlightMode.UNKNOWN,
            armed=False,
            gps_fix=GPSFixType.NO_GPS,
            satellites_visible=0,
            battery=Battery(0.0, 0.0, -1),
            heading_deg=0.0,
            ekf_ok=False,
            prearm_ok=False,
        )


@dataclass
class CommandResult:
    """Result of a command sent to the autopilot.

    Many MAVLink commands are acknowledged asynchronously with COMMAND_ACK.
    The adapter waits for that ack (with timeout) and returns this.
    """

    success: bool
    message: str = ""
    raw_result: int = 0  # MAV_RESULT code from the autopilot
