"""Abstract flight controller interface.

This is the contract. Every backend (ArduCopter, PX4, INAV) implements it.
The rest of the application — state machine, control loops, safety guard,
operator console — only ever talks to this interface, never to pymavlink
directly.

Why? Two reasons:
1. You will swap backends. Today it's ArduCopter, tomorrow maybe PX4 for a
   specific airframe, the day after maybe an INAV adapter for the bench rig.
   Application code shouldn't care.
2. You will mock it for tests. The state machine should be testable without
   any MAVLink, SITL, or simulated drone at all.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from autonomy.flight.types import CommandResult, FlightMode, Telemetry


class FlightController(ABC):
    """Abstract autopilot adapter.

    Implementations are expected to:
    - Maintain a connection (UART, UDP, etc.) to the autopilot.
    - Run a background thread that consumes telemetry and updates internal state.
    - Block (with timeout) on commands that require ack from the autopilot.
    - Raise ConnectionError on connection loss; never silently fail.
    """

    # ─── Lifecycle ─────────────────────────────────────────────────────────

    @abstractmethod
    def connect(self, timeout_s: float = 30.0) -> bool:
        """Establish connection to the autopilot.

        Returns True once the first heartbeat is received and the autopilot
        has reported its system/component IDs. Raises ConnectionError on
        timeout.
        """

    @abstractmethod
    def disconnect(self) -> None:
        """Cleanly close the connection. Idempotent."""

    @abstractmethod
    def is_connected(self) -> bool:
        """True if a recent heartbeat has been received (within ~3 seconds)."""

    # ─── State queries ─────────────────────────────────────────────────────

    @abstractmethod
    def get_telemetry(self) -> Telemetry:
        """Latest telemetry snapshot. Always returns immediately (non-blocking).

        Returns Telemetry.empty() if no data has been received yet.
        """

    @abstractmethod
    def is_armed(self) -> bool:
        """Convenience method — equivalent to get_telemetry().armed."""

    # ─── Mode and arming ───────────────────────────────────────────────────

    @abstractmethod
    def set_mode(self, mode: FlightMode, timeout_s: float = 5.0) -> CommandResult:
        """Switch to a flight mode. Blocks until ack or timeout."""

    @abstractmethod
    def arm(self, force: bool = False, timeout_s: float = 5.0) -> CommandResult:
        """Arm the motors. Requires the autopilot to pass its prearm checks.

        `force=True` bypasses some prearm checks — use only for bench testing
        and never in flight code.
        """

    @abstractmethod
    def disarm(self, force: bool = False, timeout_s: float = 5.0) -> CommandResult:
        """Disarm the motors. `force=True` disarms even while in the air —
        dangerous, only for emergencies."""

    # ─── Flight commands ───────────────────────────────────────────────────

    @abstractmethod
    def takeoff(self, altitude_m: float, timeout_s: float = 30.0) -> CommandResult:
        """Climb to the specified altitude above home.

        Requires GUIDED (or AUTO) mode and armed motors. The command returns
        once the autopilot accepts it; use wait_for_altitude() to block until
        the drone actually reaches the target altitude.
        """

    @abstractmethod
    def land(self, timeout_s: float = 5.0) -> CommandResult:
        """Land where the drone currently is."""

    @abstractmethod
    def rtl(self, timeout_s: float = 5.0) -> CommandResult:
        """Return to launch — fly home, then land."""

    @abstractmethod
    def command_velocity_body(
        self,
        vx: float,
        vy: float,
        vz: float,
        yaw_rate: float,
    ) -> None:
        """Stream a velocity setpoint in the BODY frame, m/s and rad/s.

        Body frame: +x is forward (nose direction), +y is right, +z is down.
        yaw_rate is positive clockwise looking down.

        This is the workhorse for visual servoing. Call it at 10-50 Hz while
        in GUIDED mode. Non-blocking, no ack — the autopilot ingests setpoints
        as a stream, not as discrete commands. If you stop sending, the
        autopilot will hold position (default) or trigger failsafe.
        """

    @abstractmethod
    def command_position_global(
        self,
        lat: float,
        lon: float,
        alt_m: float,
        timeout_s: float = 5.0,
    ) -> CommandResult:
        """Fly to a global GPS position. Requires GUIDED mode."""

    # ─── Waiting / synchronization helpers ─────────────────────────────────

    @abstractmethod
    def wait_for_altitude(
        self,
        target_alt_m: float,
        tolerance_m: float = 1.0,
        timeout_s: float = 30.0,
    ) -> bool:
        """Block until the drone is within `tolerance_m` of `target_alt_m`."""

    @abstractmethod
    def wait_for_armable(self, timeout_s: float = 60.0) -> bool:
        """Block until the autopilot reports it's ready to arm (GPS lock,
        EKF ok, prearm checks passing, etc.)."""
