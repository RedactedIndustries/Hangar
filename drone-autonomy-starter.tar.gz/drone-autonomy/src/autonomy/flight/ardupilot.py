"""ArduCopter implementation of the FlightController interface.

Uses pymavlink to talk to ArduCopter (real or SITL). The connection string
follows pymavlink conventions:
  - 'udp:127.0.0.1:14551'   → SITL on your laptop
  - '/dev/serial0'          → Pi UART to a real Pixhawk (with baud=921600)
  - 'tcp:192.168.1.10:5760' → SITL on another machine

Architecture:
  - One background thread reads MAVLink messages forever, updating internal
    state (latest telemetry, latest heartbeat, latest command_ack).
  - The public interface methods read that state (non-blocking) or send
    commands and wait for the corresponding ack (blocking with timeout).
  - All shared state is protected by a single lock. Telemetry updates are
    cheap, so a single lock is fine — don't optimize this until profiling
    shows you need to.
"""

from __future__ import annotations

import threading
import time
from typing import Any

from loguru import logger
from pymavlink import mavutil

from autonomy.flight.base import FlightController
from autonomy.flight.types import (
    Attitude,
    Battery,
    CommandResult,
    FlightMode,
    GPSFixType,
    Position,
    Telemetry,
    Velocity,
)

# ArduCopter custom mode numbers. Source: ArduPilot/ArduCopter/mode.h
# We only need the modes we'll actually command — extend as needed.
_ARDUCOPTER_MODES: dict[FlightMode, int] = {
    FlightMode.STABILIZE: 0,
    FlightMode.ALT_HOLD: 2,
    FlightMode.AUTO: 3,
    FlightMode.GUIDED: 4,
    FlightMode.LOITER: 5,
    FlightMode.RTL: 6,
    FlightMode.LAND: 9,
}
_MODE_BY_NUMBER: dict[int, FlightMode] = {v: k for k, v in _ARDUCOPTER_MODES.items()}


class ArduCopterController(FlightController):
    """FlightController backed by ArduCopter via pymavlink."""

    def __init__(
        self,
        connection_string: str,
        baud: int = 115200,
        source_system: int = 255,
    ) -> None:
        """
        Args:
            connection_string: pymavlink-style connection string.
            baud: serial baud rate (ignored for UDP/TCP connections).
            source_system: MAVLink system ID we identify as. 255 is the
                conventional GCS id; the autopilot is usually 1.
        """
        self._conn_str = connection_string
        self._baud = baud
        self._source_system = source_system

        self._mav: mavutil.mavfile | None = None
        self._target_system: int = 0
        self._target_component: int = 0

        # Background thread + lock-protected state
        self._lock = threading.Lock()
        self._rx_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._last_heartbeat_time: float = 0.0
        self._telemetry: Telemetry = Telemetry.empty()
        # Command acks are matched by command id — last ack for each command
        # is stored here so blocking calls can poll for their result.
        self._last_acks: dict[int, tuple[float, int]] = {}  # cmd_id -> (timestamp, result)

    # ─── Lifecycle ─────────────────────────────────────────────────────────

    def connect(self, timeout_s: float = 30.0) -> bool:
        logger.info(f"Connecting to autopilot at {self._conn_str}")
        self._mav = mavutil.mavlink_connection(
            self._conn_str,
            baud=self._baud,
            source_system=self._source_system,
            autoreconnect=True,
        )
        # Wait for the first heartbeat — this tells us the target system/component IDs.
        deadline = time.time() + timeout_s
        msg = self._mav.wait_heartbeat(timeout=timeout_s)
        if msg is None or time.time() > deadline:
            raise ConnectionError(f"No heartbeat from autopilot within {timeout_s}s")

        self._target_system = self._mav.target_system
        self._target_component = self._mav.target_component
        logger.info(
            f"Heartbeat received from system {self._target_system}, "
            f"component {self._target_component}"
        )

        # Start the rx thread before requesting data streams so we don't miss anything.
        self._stop_event.clear()
        self._rx_thread = threading.Thread(target=self._rx_loop, daemon=True, name="mavlink-rx")
        self._rx_thread.start()

        # Ask the autopilot to stream telemetry at reasonable rates.
        self._request_data_streams()
        return True

    def disconnect(self) -> None:
        logger.info("Disconnecting from autopilot")
        self._stop_event.set()
        if self._rx_thread is not None:
            self._rx_thread.join(timeout=2.0)
        if self._mav is not None:
            self._mav.close()
            self._mav = None

    def is_connected(self) -> bool:
        return (time.time() - self._last_heartbeat_time) < 3.0

    # ─── State queries ─────────────────────────────────────────────────────

    def get_telemetry(self) -> Telemetry:
        with self._lock:
            return self._telemetry

    def is_armed(self) -> bool:
        return self.get_telemetry().armed

    # ─── Mode and arming ───────────────────────────────────────────────────

    def set_mode(self, mode: FlightMode, timeout_s: float = 5.0) -> CommandResult:
        if mode not in _ARDUCOPTER_MODES:
            return CommandResult(success=False, message=f"Unsupported mode: {mode}")
        mode_number = _ARDUCOPTER_MODES[mode]
        logger.info(f"Setting mode to {mode.value} ({mode_number})")

        assert self._mav is not None
        self._mav.mav.set_mode_send(
            self._target_system,
            mavutil.mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
            mode_number,
        )

        # Poll telemetry until the mode actually changes, or timeout.
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            if self.get_telemetry().mode == mode:
                return CommandResult(success=True, message=f"Mode is now {mode.value}")
            time.sleep(0.05)

        return CommandResult(
            success=False,
            message=f"Mode did not change to {mode.value} within {timeout_s}s",
        )

    def arm(self, force: bool = False, timeout_s: float = 5.0) -> CommandResult:
        return self._send_arm_disarm(arm=True, force=force, timeout_s=timeout_s)

    def disarm(self, force: bool = False, timeout_s: float = 5.0) -> CommandResult:
        return self._send_arm_disarm(arm=False, force=force, timeout_s=timeout_s)

    def _send_arm_disarm(self, arm: bool, force: bool, timeout_s: float) -> CommandResult:
        action = "ARM" if arm else "DISARM"
        logger.info(f"{action} (force={force})")
        param1 = 1.0 if arm else 0.0
        # Magic number 21196 forces arming/disarming, bypassing safety checks.
        param2 = 21196.0 if force else 0.0
        result = self._send_command_long(
            mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM,
            param1, param2, 0, 0, 0, 0, 0,
            timeout_s=timeout_s,
        )
        return result

    # ─── Flight commands ───────────────────────────────────────────────────

    def takeoff(self, altitude_m: float, timeout_s: float = 30.0) -> CommandResult:
        logger.info(f"TAKEOFF to {altitude_m}m")
        return self._send_command_long(
            mavutil.mavlink.MAV_CMD_NAV_TAKEOFF,
            0, 0, 0, 0, 0, 0, altitude_m,
            timeout_s=timeout_s,
        )

    def land(self, timeout_s: float = 5.0) -> CommandResult:
        logger.info("LAND")
        return self._send_command_long(
            mavutil.mavlink.MAV_CMD_NAV_LAND,
            0, 0, 0, 0, 0, 0, 0,
            timeout_s=timeout_s,
        )

    def rtl(self, timeout_s: float = 5.0) -> CommandResult:
        logger.info("RTL")
        return self._send_command_long(
            mavutil.mavlink.MAV_CMD_NAV_RETURN_TO_LAUNCH,
            0, 0, 0, 0, 0, 0, 0,
            timeout_s=timeout_s,
        )

    def command_velocity_body(
        self,
        vx: float,
        vy: float,
        vz: float,
        yaw_rate: float,
    ) -> None:
        """Send a velocity setpoint in the body frame.

        Uses SET_POSITION_TARGET_LOCAL_NED with the MAV_FRAME_BODY_NED frame
        and a type_mask that tells the autopilot to use only velocity + yaw_rate
        (ignoring position, acceleration, and absolute yaw).
        """
        assert self._mav is not None

        # type_mask: bit set = "ignore this field"
        # We want to USE: vx, vy, vz, yaw_rate
        # We want to IGNORE: position (x,y,z), acceleration (afx,afy,afz), yaw
        type_mask = (
            0b0000_0111_1100_0111  # ignore pos, ignore accel, ignore yaw
        )
        # Bit layout (bit 0 = LSB):
        # 0:x 1:y 2:z 3:vx 4:vy 5:vz 6:afx 7:afy 8:afz 9:force_set 10:yaw 11:yaw_rate
        # So "use vx,vy,vz,yaw_rate" = ignore everything else:
        # ignore x,y,z = bits 0,1,2 = 0x007
        # ignore afx,afy,afz = bits 6,7,8 = 0x1C0
        # ignore yaw = bit 10 = 0x400
        # Total ignored = 0x007 | 0x1C0 | 0x400 = 0x5C7
        type_mask = 0x05C7

        self._mav.mav.set_position_target_local_ned_send(
            0,  # time_boot_ms (autopilot ignores when streaming setpoints)
            self._target_system,
            self._target_component,
            mavutil.mavlink.MAV_FRAME_BODY_NED,
            type_mask,
            0, 0, 0,            # position (ignored)
            vx, vy, vz,         # velocity m/s
            0, 0, 0,            # acceleration (ignored)
            0,                  # yaw (ignored)
            yaw_rate,           # yaw rate rad/s
        )

    def command_position_global(
        self,
        lat: float,
        lon: float,
        alt_m: float,
        timeout_s: float = 5.0,
    ) -> CommandResult:
        logger.info(f"GOTO global: lat={lat}, lon={lon}, alt={alt_m}m")
        assert self._mav is not None
        # type_mask: use position only, ignore velocity/accel/yaw
        type_mask = 0b0000_1111_1111_1000
        self._mav.mav.set_position_target_global_int_send(
            0,
            self._target_system,
            self._target_component,
            mavutil.mavlink.MAV_FRAME_GLOBAL_RELATIVE_ALT_INT,
            type_mask,
            int(lat * 1e7),
            int(lon * 1e7),
            alt_m,
            0, 0, 0,
            0, 0, 0,
            0, 0,
        )
        return CommandResult(success=True, message="Position target sent")

    # ─── Waiting helpers ───────────────────────────────────────────────────

    def wait_for_altitude(
        self,
        target_alt_m: float,
        tolerance_m: float = 1.0,
        timeout_s: float = 30.0,
    ) -> bool:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            tel = self.get_telemetry()
            if tel.position is not None:
                if abs(tel.position.relative_alt_m - target_alt_m) <= tolerance_m:
                    return True
            time.sleep(0.1)
        return False

    def wait_for_armable(self, timeout_s: float = 60.0) -> bool:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            tel = self.get_telemetry()
            if (
                tel.prearm_ok
                and tel.ekf_ok
                and tel.gps_fix.value >= GPSFixType.FIX_3D.value
                and tel.satellites_visible >= 6
            ):
                return True
            time.sleep(0.5)
        return False

    # ─── Internal: rx loop and command sending ─────────────────────────────

    def _rx_loop(self) -> None:
        """Background thread: read every MAVLink message and update state."""
        assert self._mav is not None
        logger.debug("MAVLink rx thread started")

        # Cache the latest values we need to assemble a Telemetry snapshot.
        # We don't publish a partial Telemetry — we wait until we've seen at
        # least one of each critical message type, then publish coherent
        # snapshots on each new HEARTBEAT.
        latest: dict[str, Any] = {}

        while not self._stop_event.is_set():
            try:
                msg = self._mav.recv_match(blocking=True, timeout=1.0)
            except Exception as e:  # noqa: BLE001
                logger.warning(f"MAVLink recv error: {e}")
                continue

            if msg is None:
                continue

            mtype = msg.get_type()
            latest[mtype] = msg

            if mtype == "HEARTBEAT":
                self._last_heartbeat_time = time.time()
                # Heartbeat is our cue to publish a new Telemetry snapshot.
                self._publish_telemetry(latest)
            elif mtype == "COMMAND_ACK":
                # Store ack so the caller of _send_command_long can find it.
                with self._lock:
                    self._last_acks[msg.command] = (time.time(), msg.result)

        logger.debug("MAVLink rx thread exiting")

    def _publish_telemetry(self, latest: dict[str, Any]) -> None:
        """Assemble a Telemetry snapshot from the latest cached messages."""
        hb = latest.get("HEARTBEAT")
        att = latest.get("ATTITUDE")
        gpi = latest.get("GLOBAL_POSITION_INT")
        gps = latest.get("GPS_RAW_INT")
        sys_status = latest.get("SYS_STATUS")
        vfr = latest.get("VFR_HUD")

        if hb is None:
            return

        # Mode
        mode = _MODE_BY_NUMBER.get(hb.custom_mode, FlightMode.UNKNOWN)
        armed = bool(hb.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)

        # Attitude
        attitude = (
            Attitude(att.roll, att.pitch, att.yaw)
            if att is not None
            else Attitude(0.0, 0.0, 0.0)
        )

        # Position + velocity (GLOBAL_POSITION_INT bundles both)
        position = None
        velocity = Velocity(0.0, 0.0, 0.0)
        if gpi is not None:
            position = Position(
                lat=gpi.lat / 1e7,
                lon=gpi.lon / 1e7,
                alt_m=gpi.alt / 1000.0,
                relative_alt_m=gpi.relative_alt / 1000.0,
            )
            velocity = Velocity(
                vx_ned=gpi.vx / 100.0,
                vy_ned=gpi.vy / 100.0,
                vz_ned=gpi.vz / 100.0,
            )

        # GPS quality
        gps_fix = GPSFixType.NO_GPS
        satellites = 0
        if gps is not None:
            try:
                gps_fix = GPSFixType(gps.fix_type)
            except ValueError:
                gps_fix = GPSFixType.NO_GPS
            satellites = gps.satellites_visible

        # Battery
        battery = Battery(0.0, 0.0, -1)
        if sys_status is not None:
            battery = Battery(
                voltage_v=sys_status.voltage_battery / 1000.0,
                current_a=sys_status.current_battery / 100.0,
                remaining_pct=sys_status.battery_remaining,
            )
        prearm_ok = (
            sys_status is not None
            and (sys_status.onboard_control_sensors_health
                 & mavutil.mavlink.MAV_SYS_STATUS_PREARM_CHECK) != 0
        ) if sys_status else False

        # Heading
        heading = vfr.heading if vfr is not None else 0.0

        # EKF — checked via EKF_STATUS_REPORT if you want to be thorough.
        # For POC we approximate: EKF is fine if we have a 3D fix and prearm passes.
        ekf_ok = gps_fix.value >= GPSFixType.FIX_3D.value

        snapshot = Telemetry(
            timestamp=time.time(),
            position=position,
            attitude=attitude,
            velocity=velocity,
            mode=mode,
            armed=armed,
            gps_fix=gps_fix,
            satellites_visible=satellites,
            battery=battery,
            heading_deg=float(heading),
            ekf_ok=ekf_ok,
            prearm_ok=prearm_ok,
        )

        with self._lock:
            self._telemetry = snapshot

    def _send_command_long(
        self,
        command: int,
        p1: float, p2: float, p3: float, p4: float,
        p5: float, p6: float, p7: float,
        timeout_s: float = 5.0,
    ) -> CommandResult:
        """Send a COMMAND_LONG and wait for COMMAND_ACK with timeout."""
        assert self._mav is not None

        # Clear any stale ack for this command id.
        with self._lock:
            self._last_acks.pop(command, None)
        ack_time_before = time.time()

        self._mav.mav.command_long_send(
            self._target_system,
            self._target_component,
            command,
            0,                      # confirmation
            p1, p2, p3, p4, p5, p6, p7,
        )

        # Poll for the ack
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            with self._lock:
                ack = self._last_acks.get(command)
            if ack is not None and ack[0] > ack_time_before:
                ts, result = ack
                ok = result == mavutil.mavlink.MAV_RESULT_ACCEPTED
                return CommandResult(
                    success=ok,
                    message=_mav_result_string(result),
                    raw_result=result,
                )
            time.sleep(0.02)

        return CommandResult(
            success=False,
            message=f"Timeout waiting for COMMAND_ACK on cmd {command}",
        )

    def _request_data_streams(self) -> None:
        """Ask the autopilot to send telemetry at useful rates.

        For SITL these are usually already streamed at default rates, but it
        doesn't hurt to be explicit. Real flight controllers sometimes need
        the kick.
        """
        assert self._mav is not None
        # MAV_DATA_STREAM_ALL at 10 Hz is a sensible default for development.
        self._mav.mav.request_data_stream_send(
            self._target_system,
            self._target_component,
            mavutil.mavlink.MAV_DATA_STREAM_ALL,
            10,    # rate Hz
            1,     # 1 = start
        )


def _mav_result_string(result: int) -> str:
    """Translate MAV_RESULT enum to a human string."""
    return {
        0: "ACCEPTED",
        1: "TEMPORARILY_REJECTED",
        2: "DENIED",
        3: "UNSUPPORTED",
        4: "FAILED",
        5: "IN_PROGRESS",
        6: "CANCELLED",
    }.get(result, f"UNKNOWN({result})")
