"""Logging configuration using loguru.

Call setup_logging() once at the top of your entry point (main.py or any
script). After that, just `from loguru import logger` anywhere.
"""

from __future__ import annotations

import sys
from pathlib import Path

from loguru import logger


def setup_logging(
    level: str = "INFO",
    log_dir: Path | str | None = None,
    log_file_level: str = "DEBUG",
) -> None:
    """Configure loguru for the application.

    Args:
        level: minimum level for console output.
        log_dir: if provided, also writes a rotating log file here.
        log_file_level: minimum level for file output (usually more verbose
            than console).
    """
    # Remove the default handler so we don't double-log.
    logger.remove()

    # Console handler — colored, human readable.
    logger.add(
        sys.stderr,
        level=level,
        format=(
            "<green>{time:HH:mm:ss.SSS}</green> "
            "<level>{level: <8}</level> "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> "
            "- <level>{message}</level>"
        ),
        colorize=True,
    )

    # File handler — JSON, machine readable, with rotation.
    if log_dir is not None:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        logger.add(
            log_dir / "autonomy_{time:YYYY-MM-DD}.log",
            level=log_file_level,
            rotation="100 MB",
            retention="14 days",
            compression="zip",
            serialize=True,  # JSON output
            enqueue=True,    # thread-safe
        )

    logger.info(f"Logging configured: console={level}, log_dir={log_dir}")
