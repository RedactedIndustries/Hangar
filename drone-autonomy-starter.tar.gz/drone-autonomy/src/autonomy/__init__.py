"""drone-autonomy: companion software for autonomous drone missions."""

__version__ = "0.1.0"
