"""Hello world for the FC adapter.

Connects to ArduCopter SITL, arms, takes off, hovers, lands, disconnects.

Usage (with SITL already running on localhost):
    python scripts/sitl_test_takeoff.py

By default this connects to udp:127.0.0.1:14551. If you launched SITL via
Mission Planner, port 14550 is typically taken by MP — use MAVProxy to
forward to 14551 (see README), or point this script at a different port.

The point of this script is to validate the full software stack end-to-end
before you have a real drone. If this works, your dev environment is sound.
"""

from __future__ import annotations

import argparse
import sys
import time

from loguru import logger

from autonomy.flight import FlightMode
from autonomy.flight.ardupilot import ArduCopterController
from autonomy.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser(description="SITL takeoff smoke test")
    parser.add_argument(
        "--connection",
        default="udp:127.0.0.1:14551",
        help="MAVLink connection string (default: udp:127.0.0.1:14551)",
    )
    parser.add_argument(
        "--altitude",
        type=float,
        default=10.0,
        help="Takeoff altitude in meters (default: 10)",
    )
    parser.add_argument(
        "--hover-seconds",
        type=float,
        default=5.0,
        help="How long to hover before landing (default: 5)",
    )
    args = parser.parse_args()

    setup_logging(level="INFO")
    logger.info("=== SITL takeoff test ===")

    fc = ArduCopterController(args.connection)

    try:
        # 1. Connect.
        logger.info("Step 1: connect")
        fc.connect(timeout_s=30.0)

        # 2. Wait until the autopilot is happy to be armed.
        logger.info("Step 2: wait for armable (this can take 30-60s in SITL)")
        if not fc.wait_for_armable(timeout_s=90.0):
            tel = fc.get_telemetry()
            logger.error(
                f"Autopilot not armable. gps_fix={tel.gps_fix.name}, "
                f"sats={tel.satellites_visible}, ekf_ok={tel.ekf_ok}, "
                f"prearm_ok={tel.prearm_ok}"
            )
            return 1

        # 3. Switch to GUIDED mode. Required for companion-driven takeoff.
        logger.info("Step 3: set mode GUIDED")
        result = fc.set_mode(FlightMode.GUIDED)
        if not result.success:
            logger.error(f"Mode change failed: {result.message}")
            return 1

        # 4. Arm motors.
        logger.info("Step 4: arm")
        result = fc.arm()
        if not result.success:
            logger.error(f"Arm failed: {result.message}")
            return 1

        # 5. Takeoff.
        logger.info(f"Step 5: takeoff to {args.altitude}m")
        result = fc.takeoff(args.altitude)
        if not result.success:
            logger.error(f"Takeoff command rejected: {result.message}")
            return 1

        logger.info("Waiting to reach target altitude...")
        if not fc.wait_for_altitude(args.altitude, tolerance_m=0.5, timeout_s=30.0):
            tel = fc.get_telemetry()
            current_alt = tel.position.relative_alt_m if tel.position else 0.0
            logger.error(f"Did not reach {args.altitude}m within 30s (at {current_alt:.1f}m)")
            return 1

        logger.success(f"Reached {args.altitude}m. Hovering for {args.hover_seconds}s")
        # Print telemetry while hovering so you can see it working.
        for _ in range(int(args.hover_seconds)):
            tel = fc.get_telemetry()
            assert tel.position is not None
            logger.info(
                f"  alt={tel.position.relative_alt_m:.2f}m  "
                f"yaw={tel.attitude.yaw:.2f}rad  "
                f"batt={tel.battery.voltage_v:.1f}V  "
                f"mode={tel.mode.value}"
            )
            time.sleep(1.0)

        # 6. Land.
        logger.info("Step 6: land")
        result = fc.land()
        if not result.success:
            logger.warning(f"Land command response: {result.message}")

        # Wait for disarm (LAND mode auto-disarms on touchdown).
        logger.info("Waiting for landing + auto-disarm...")
        deadline = time.time() + 60.0
        while time.time() < deadline and fc.is_armed():
            time.sleep(0.5)

        if fc.is_armed():
            logger.warning("Still armed after 60s; forcing disarm")
            fc.disarm(force=True)
        else:
            logger.success("Landed and disarmed.")

        return 0

    except KeyboardInterrupt:
        logger.warning("Interrupted by user — attempting RTL")
        try:
            fc.rtl()
        except Exception as e:  # noqa: BLE001
            logger.error(f"RTL failed: {e}")
        return 130

    except Exception as e:  # noqa: BLE001
        logger.exception(f"Unexpected error: {e}")
        return 1

    finally:
        fc.disconnect()
        logger.info("=== Test complete ===")


if __name__ == "__main__":
    sys.exit(main())
