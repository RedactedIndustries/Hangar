"""Fly a square using body-frame velocity commands.

Demonstrates the workhorse pattern your visual servoing controller will use:
streaming SET_POSITION_TARGET_LOCAL_NED setpoints at 10 Hz while in GUIDED.

The drone takes off, then for each side of the square: streams a forward
velocity command for N seconds, then yaws 90 degrees, then repeats.

Usage:
    python scripts/sitl_fly_square.py
"""

from __future__ import annotations

import argparse
import math
import sys
import time

from loguru import logger

from autonomy.flight import FlightMode
from autonomy.flight.ardupilot import ArduCopterController
from autonomy.logging import setup_logging


def stream_velocity(fc: ArduCopterController, vx: float, vy: float, vz: float,
                    yaw_rate: float, duration_s: float, hz: float = 10.0) -> None:
    """Stream a velocity setpoint for `duration_s` seconds at `hz`."""
    interval = 1.0 / hz
    end = time.time() + duration_s
    while time.time() < end:
        fc.command_velocity_body(vx, vy, vz, yaw_rate)
        time.sleep(interval)


def main() -> int:
    parser = argparse.ArgumentParser(description="Fly a square in SITL")
    parser.add_argument("--connection", default="udp:127.0.0.1:14551")
    parser.add_argument("--altitude", type=float, default=10.0)
    parser.add_argument("--side-seconds", type=float, default=4.0,
                        help="Seconds per side of the square (default: 4)")
    parser.add_argument("--speed", type=float, default=2.0,
                        help="Forward speed in m/s (default: 2)")
    args = parser.parse_args()

    setup_logging(level="INFO")
    fc = ArduCopterController(args.connection)

    try:
        fc.connect(timeout_s=30.0)
        if not fc.wait_for_armable(timeout_s=90.0):
            logger.error("Not armable")
            return 1
        fc.set_mode(FlightMode.GUIDED)
        fc.arm()
        fc.takeoff(args.altitude)
        if not fc.wait_for_altitude(args.altitude, tolerance_m=0.5, timeout_s=30.0):
            logger.error("Did not reach altitude")
            return 1

        logger.success(f"At {args.altitude}m. Flying a square.")

        for side in range(4):
            logger.info(f"Side {side + 1}/4: forward {args.speed} m/s for {args.side_seconds}s")
            stream_velocity(fc, vx=args.speed, vy=0, vz=0, yaw_rate=0,
                            duration_s=args.side_seconds)

            # Stop, then yaw 90 degrees.
            logger.info(f"Yawing 90 degrees (corner {side + 1})")
            # yaw_rate of pi/2 rad/s for 1s = 90 degrees
            yaw_duration = 1.0
            yaw_rate = math.pi / 2.0 / yaw_duration
            stream_velocity(fc, vx=0, vy=0, vz=0, yaw_rate=yaw_rate,
                            duration_s=yaw_duration)

            # Brief pause to settle.
            stream_velocity(fc, vx=0, vy=0, vz=0, yaw_rate=0, duration_s=0.5)

        logger.success("Square complete. Returning to launch.")
        fc.rtl()
        time.sleep(5)  # let RTL get started before we log out

        return 0

    except KeyboardInterrupt:
        logger.warning("Interrupted — RTL")
        fc.rtl()
        return 130
    except Exception as e:  # noqa: BLE001
        logger.exception(f"Error: {e}")
        return 1
    finally:
        fc.disconnect()


if __name__ == "__main__":
    sys.exit(main())
