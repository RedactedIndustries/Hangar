"""Smoke test for flight types — exercises the dataclass plumbing.

These are intentionally trivial. The point is to demonstrate the testing
pattern: types and behavior should be testable without any MAVLink or SITL.
Real coverage comes when we add the mission state machine, which we'll test
against a mock FlightController.
"""

from autonomy.flight.types import (
    Attitude,
    FlightMode,
    GPSFixType,
    Position,
    Telemetry,
)


def test_telemetry_empty_is_safe() -> None:
    """The 'no data yet' telemetry should be unambiguous."""
    tel = Telemetry.empty()
    assert tel.position is None
    assert tel.armed is False
    assert tel.mode == FlightMode.UNKNOWN
    assert tel.gps_fix == GPSFixType.NO_GPS
    assert tel.ekf_ok is False
    assert tel.prearm_ok is False


def test_position_construction() -> None:
    pos = Position(lat=37.7749, lon=-122.4194, alt_m=50.0, relative_alt_m=10.0)
    assert pos.lat == 37.7749
    assert pos.relative_alt_m == 10.0


def test_attitude_construction() -> None:
    att = Attitude(roll=0.1, pitch=-0.2, yaw=1.57)
    assert att.yaw == 1.57


def test_flight_mode_is_string_enum() -> None:
    """FlightMode values are usable as plain strings — useful for YAML configs."""
    assert FlightMode.GUIDED.value == "GUIDED"
    assert FlightMode("GUIDED") == FlightMode.GUIDED


def test_gps_fix_type_ordering() -> None:
    """Fix quality should be orderable — used in 'is fix good enough' checks."""
    assert GPSFixType.FIX_3D.value > GPSFixType.FIX_2D.value
    assert GPSFixType.RTK_FIXED.value > GPSFixType.FIX_3D.value
