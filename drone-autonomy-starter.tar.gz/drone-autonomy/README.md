# drone-autonomy

Companion software for autonomous drone missions.
Pi 5 + AI Hat+ (Hailo-8) running perception, ArduCopter as the flight controller.

This is the **week-1 starter kit** — it implements the flight controller
adapter (ArduCopter via MAVLink) and two test scripts that exercise it
against SITL. No perception, state machine, or safety layer yet — those
come in subsequent weeks.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  YOUR APPLICATION (to be built)                         │
│  - mission state machine                                │
│  - visual servoing controller                           │
│  - safety guard                                         │
│  - operator console                                     │
├─────────────────────────────────────────────────────────┤
│  flight.FlightController (abstract interface)  ← here   │
│         └── flight.ArduCopterController        ← here   │
├─────────────────────────────────────────────────────────┤
│  pymavlink → MAVLink → ArduCopter (SITL or real)        │
└─────────────────────────────────────────────────────────┘
```

## Setup

### On your dev laptop (Windows/Mac/Linux)

```bash
# 1. Create a virtual environment
python -m venv .venv
source .venv/bin/activate          # Linux/Mac
# .venv\Scripts\activate            # Windows

# 2. Install the package in editable mode with dev dependencies
pip install -e ".[dev]"
```

### Run SITL

You have two options:

**Option A — Mission Planner's built-in SITL (Windows, easiest).**
Open Mission Planner → top menu → `Simulation` → `Multirotor` → `Quadcopter`.
It downloads SITL the first time and auto-connects on UDP port 14550.

**Option B — Standalone `sim_vehicle.py` (any OS, recommended for real dev).**
Install the ArduPilot dev environment (Ubuntu or WSL2 on Windows), then:

```bash
cd ardupilot
./Tools/autotest/sim_vehicle.py -v ArduCopter --map --console
```

### Forward a UDP port for your script

Mission Planner / `sim_vehicle.py` opens MAVLink on UDP `14550` by default.
You want a *second* port so your Python script can connect alongside the GCS.

If you're using `sim_vehicle.py`, pass `--out=udp:127.0.0.1:14551` to add a
forwarded port:

```bash
./Tools/autotest/sim_vehicle.py -v ArduCopter --map --console --out=udp:127.0.0.1:14551
```

If you're using Mission Planner's built-in SITL, run MAVProxy alongside:

```bash
mavproxy.py --master=udp:127.0.0.1:14550 --out=udp:127.0.0.1:14551
```

## Run the smoke tests

```bash
# 1. Take off, hover, land.
python scripts/sitl_test_takeoff.py

# 2. Fly a square using velocity setpoints (the pattern visual servoing uses).
python scripts/sitl_fly_square.py
```

Watch the simulated drone in Mission Planner's map or the SITL `--map`
window — it should arm, lift off, perform the maneuver, and land.

If the takeoff test passes, your dev environment works end-to-end. This is
milestone 1.

## Project structure

```
src/autonomy/
├── flight/
│   ├── base.py          # abstract FlightController interface
│   ├── ardupilot.py     # ArduCopter implementation (pymavlink)
│   └── types.py         # Telemetry, FlightMode, Position, etc.
└── logging/
    └── setup.py         # loguru configuration

scripts/
├── sitl_test_takeoff.py # arm/takeoff/land hello world
└── sitl_fly_square.py   # streaming velocity commands

config/
└── default.yaml         # configuration (not used yet)
```

## Next milestones

- **Week 2**: perception module (camera + Hailo inference + tracker)
- **Week 3**: mission state machine + visual servoing controller
- **Week 4**: safety guard + bench testing
- **Week 5**: operator console
- **Week 6**: first real flight
